<?php $__env->startSection('content'); ?>

    <div class="panel panel-default">
        <div class="panel-body">
            <?php echo $__env->make('common.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <form action="<?php echo e(url('task')); ?>" class="form-horizontal" method="post" role="form">
                <div class="form-group">
                    <label class="col-sm-3 control-label" for="name">
                        TaskList
                    </label>
                    <div class="col-sm-6">
                        <input class="form-control" id="name" name="name" title="" type="text" value="">
                        </input>
                    </div>
                </div>
                <div class="form-group">
                    <div class="col-sm-offset-3 col-sm-6 ">
                        <button class="btn btn-primary" type="submit">
                            Add tasks
                        </button>
                    </div>
                </div>
                <?php echo e(csrf_field()); ?>  
            </form>

        </div>
        <?php if($tasks->count()): ?>
        <div class="panel panel-default">
            <div class="panel-heading">
                <h3 class="panel-title">
                    <span><b><center>Current Tasks</center></b></span>
                </h3>
            </div>
            <div class="panel-body">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>
                                Tasks
                            </th>
                            <th>
                            </th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                        <tr>
                            <td>
                                <?php echo e($task->name); ?>

                            </td>
                            <td>
                                <form action="<?php echo e(url('task/'. $task->id)); ?>" class="form-horizontal" method="post" role="form">
                                    <button class="btn btn-danger" type="submit">
                                        Delete
                                    </button>
                                    <?php echo e(method_field('delete')); ?>

                                    <?php echo e(csrf_field()); ?>

                                </form>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
        <?php endif; ?> 
    </div>
<?php $__env->stopSection(); ?> 

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>